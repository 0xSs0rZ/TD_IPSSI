#!/bin/bash
#Run apache
service apache2 start

#Run MariaDB
service mysql start

#Create User
/usr/bin/mysql -u root -p="" --execute="CREATE USER 'pentesterlab' IDENTIFIED BY 'pentesterlab';"
/usr/bin/mysql -u root -p="" --execute="GRANT ALL privileges ON *.* TO 'pentesterlab'@localhost IDENTIFIED BY 'pentesterlab';"
/usr/bin/mysql -u root -p="" --execute='flush privileges';
#Restore Database
/usr/bin/mysql -u pentesterlab -ppentesterlab < /opt/web_for_pentest.sql

rm /opt/web_for_pentest.sql

tail -f /var/log/apache2/access.log
