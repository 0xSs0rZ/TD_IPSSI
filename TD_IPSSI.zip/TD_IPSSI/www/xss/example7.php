
<?php require_once '../header.php'; ?>
Hello 
<script>
	var $a= '<?php  echo htmlentities($_GET["name"]); ?>';
</script>
	
<?php require_once '../footer.php'; ?>

