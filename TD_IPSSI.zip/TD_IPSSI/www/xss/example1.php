<?php require_once '../header.php'; ?>
<html>
Hello 
<?php 
	echo $_GET["name"];
?>

<?php require_once '../footer.php'; ?>

