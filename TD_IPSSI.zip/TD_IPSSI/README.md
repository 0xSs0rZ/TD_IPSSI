# Web for pentest  
This was docker version of Web for Pentester 1 from [pentesterlab](https://pentesterlab.com/)  
  
  
## How to use?  
first you must install docker and start the daemon  
```
docker pull justhumanz/web_for_pentest
docker run -itd --name pentest -p 8888:80 justhumanz/web_for_pentest
```
and open http://localhost:8888  
Happy Hacking
